# Ci > 2024-02-09 7:30pm
https://universe.roboflow.com/test-ly2zk/ci-yijx6

Provided by a Roboflow user
License: CC BY 4.0

